from .functions import train, test, save_latent_info, save_checkpoint, load_checkpoint, pdist, NN_lookup, augment_MNIST_SVHN, sent_emb
from .classes import Categorical, CategoricalImage