from .MNIST import MNIST
from .MNIST_MNIST import MNIST_MNIST
from .MNIST_SVHN import MNIST_SVHN
from .MNIST_GM import MNIST_GM
from .CUB import CUB
